import numpy as np
x = np.array([1,2,3])
q = [1]
q.append(x)
print(q[1])
cost = np.zeros((3,4))
print(cost)
t = 3**2
t = np.sqrt(t)
print(t)